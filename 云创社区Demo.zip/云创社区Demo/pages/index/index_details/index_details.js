// pages/index/index_details/index_details.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentProject:"",
    prize_m_id:"",
    num_prize:"",
    focus_m_id:"",
    join_m_id:"",
    username:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    let object = JSON.parse(options.project)
    this.setData({
      currentProject: object,
      prize_m_id: object.prize_m_id,
      num_prize: object.num_prize,
      focus_m_id: object.focus_m_id,
      join_m_id: object.focus_m_id,
      username: app.globalData.myInfo.username
    })
    console.log(object.prize_m_id)
    console.log(object.num_prize)
    var that = this
    wx.request({
      url: 'https://czw.saleii.com/api/client/get_projectmember_joinlist',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded', // 默认值
        'Accept': 'application/json'
      },
      data: {
        username: app.globalData.myInfo.username,
        access_token: app.globalData.myInfo.token,
        post_id: object.id
      },
      success(res) {
        that.setData({
          user_items: res.data.result
        })
      }
    })
    
  },
  tochat:function(){
    wx.navigateTo({
      url: 'chat/chat',
    })
  },
  tophoto:function(){
    wx.navigateTo({
      url: 'project_photoes/project_photoes?project=' + JSON.stringify(this.data.currentProject),
    })
  },
  toOther_user:function(){
    wx.navigateTo({
      url: '../../other_user/other_user?project=' + JSON.stringify(this.data.currentProject), 
    })
  },
  //分享按钮函数
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '我的小程序',
      path: 'pages/index/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },
  doprize:function(event){
    var that = this
      var pid = event.currentTarget.dataset.pid
      wx.request({
        url: 'https://czw.saleii.com/api/client/post_prize',
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded', // 默认值
          'Accept': 'application/json'
        },
        data :{
          username: app.globalData.myInfo.username,
          access_token: app.globalData.token,
          post_id: pid
        },
        success:function(){
          wx.request({
            url: 'https://czw.saleii.com/api/client/get_project_list',
            method: 'POST',
            header: {
              'content-type': 'application/x-www-form-urlencoded', // 默认值
              'Accept': 'application/json'
            },
            data: {
              username: app.globalData.myInfo.username,
              access_token: app.globalData.token,
              project_id: pid
            },success:function(res){
              that.setData({
                prize_m_id: res.data.result[0].prize_m_id,
                num_prize: res.data.result[0].num_prize
              })
            }
          })
        }
      })
  },
  dojoin: function (event){
    var that = this
    var pid = event.currentTarget.dataset.pid
    wx.request({
      url: 'https://czw.saleii.com/api/client/post_join',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded', // 默认值
        'Accept': 'application/json'
      },
      data: {
        username: app.globalData.myInfo.username,
        access_token: app.globalData.token,
        post_id: pid
      },
      success: function () {
        wx.request({
          url: 'https://czw.saleii.com/api/client/get_project_list',
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded', // 默认值
            'Accept': 'application/json'
          },
          data: {
            username: app.globalData.myInfo.username,
            access_token: app.globalData.token,
            project_id: pid
          }, success: function (res) {
            that.setData({
              join_m_id: res.data.result[0].join_m_id,
              num_join: res.data.result[0].num_join
            })
          }
        })
      }
    })
  },
  dofocus: function (event){
    var that = this
    var pid = event.currentTarget.dataset.pid
    wx.request({
      url: 'https://czw.saleii.com/api/client/post_focus',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded', // 默认值
        'Accept': 'application/json'
      },
      data: {
        username: app.globalData.myInfo.username,
        access_token: app.globalData.token,
        post_id: pid
      },
      success: function () {
        wx.request({
          url: 'https://czw.saleii.com/api/client/get_project_list',
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded', // 默认值
            'Accept': 'application/json'
          },
          data: {
            username: app.globalData.myInfo.username,
            access_token: app.globalData.token,
            project_id: pid
          }, success: function (res) {
            that.setData({
              focus_m_id: res.data.result[0].focus_m_id,
              num_focus: res.data.result[0].num_focus
            })
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})
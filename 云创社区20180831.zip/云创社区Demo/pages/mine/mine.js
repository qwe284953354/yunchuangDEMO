// pages/mine/mine.js
import wecache from "../../utils/wecache.js"
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: { 
    userInfo: null,
    phoneNo: null,
    sms_code: null,
    info: "",
    myInfo: null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    that.setData({
      userInfo: app.globalData.userInfo,
      myInfo: wecache.get("myInfo", "0"),
      getinfo: wecache.get("getinfo", "0")
    })
    if (wecache.get("myInfo", "0")==0) {
      wx.showModal({
        title: '重要',
        content: '我们需要获取您的微信权限才能体验我们的产品。',
        success: function (res) {
          if (res.confirm) {
            that.setData({
              hasUserInfo: true
            })
            wx.navigateTo({
              url: 'getUserInfo/getUserInfo',
            })
          } else if (res.cancel) {
            wx.showToast({
              title: '失败',
              icon: 'loading',
              duration: 2000
            })
          }
        }
      })
    }
  },
  ToUser_Info: function () {
    wx.navigateTo({
      url: 'user_info/user_info',
    })
  },
  ToUser_Confirm: function () {
    wx.navigateTo({
      url: 'user_confirm/user_confirm',
    })
  },
  phoneNoInput: function (event) {
    this.setData({
      phoneNo: event.detail.value
    })
  },
  SmscodeInput: function (event) {
    this.setData({
      sms_code: event.detail.value
    })
  },
  getSmscode: function () {
    var that = this
    wx.request({
      url: 'https://czw.saleii.com/api/web/user/login/login_sms_send',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded', // 默认值
        'Accept': 'application/json'
      },
      data: {
        phoneNo: this.data.phoneNo
      },
      success: function (res) {
        if (res.data.info) {
          that.setData({
            info: res.data.info
          })
        } else {
          that.setData({
            info: "获取成功"
          })
        }
      }
    })
  },
  tipsClear: function () {
    var that = this
    that.setData({
      info: ""
    })
  },
  dologin: function () {
    var that = this
    wx.request({
      url: 'https://czw.saleii.com/api/web/user/login/user_xcx_login',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded', // 默认值
        'Accept': 'application/json'
      },
      data: {
        username: this.data.phoneNo,
        smscode: this.data.sms_code,
        wx_nickname: app.globalData.userInfo.nickName,
        wx_headimg: app.globalData.userInfo.avatarUrl,
        openid: app.globalData.openid
      },
      success: function (res) {
        if (res.data.status == "n") {
          that.setData({
            info: res.data.info
          })
        } else {
          wecache.put("myInfo", res.data.result,6000)
          var myInfo = wecache.get("myInfo")
          setTimeout(function () {
            that.setData({
              // token: res.data.result.token,
              // myInfo: res.data.result
              myInfo: myInfo
            })
            app.globalData.myInfo = myInfo
            app.globalData.token = myInfo.token
            setTimeout(function () {
              wx.request({
                url: 'https://czw.saleii.com/api/client/get_name',
                method: 'POST',
                header: {
                  'content-type': 'application/x-www-form-urlencoded', // 默认值
                  'Accept': 'application/json'
                },
                data: {
                  username: that.data.phoneNo,
                  access_token: app.globalData.token
                },
                success: function (res) {
                  wecache.put("getinfo", res.data.result,6000)
                  setTimeout(function () {
                    that.setData({
                      getinfo: wecache.get("getinfo")
                    })
                  },500)
                }
              })
            },500)
            
          },500)
        }
      }
    })
  },
  toMy_cia:function(){
    wx.navigateTo({
      url: 'my_cia/mycia',
    })
  },
  toMy_activity:function(){
    wx.navigateTo({
      url: 'my_activity/my_activity',
    })
  },
  toMy_idea:function(){
    wx.navigateTo({
      url: 'my_idea/myidea',
    })
  },
  toOpration:function(){
    wx.navigateTo({
      url: 'oprations/oprations',
    })
  },
  tofeedback:function(){
    wx.navigateTo({
      url: 'feedback/feedback',
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})